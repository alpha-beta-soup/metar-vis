var {{ circle }} = L.circle([{{ lat }}, {{ lon }}], {{ radius }}, {
                            color: '{{ line_color }}',
                            fillColor: '{{ fill_color }}',
                            fillOpacity: {{ fill_opacity }}
                            });